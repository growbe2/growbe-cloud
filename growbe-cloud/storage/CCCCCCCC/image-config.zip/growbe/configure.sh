#! /bin/bash

systemctl daemon-reload


systemctl enable autossh@dev.service
systemctl start autossh@dev.service

systemctl enable fluentbit@dev.service
systemctl start fluentbit@dev.service

systemctl enable growbe-mainboard@dev.service
systemctl start growbe-mainboard@dev.service

